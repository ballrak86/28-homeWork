import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Тестовое приложение Алексея,<br/> 
          созданное с помощью<code> npm create-react-app</code> и сдеплоенно <br/>
          с помощью следующих команд: 
        </p>
        <ol>
          <li>yum install node</li>
          <li>npm init</li>
          <li>npx create-react-app alenchik-app <br/>(defaults packages node-modules installed)</li>
          <li>cd alenchik-app && npm run tests && npm run build</li>
          <li>cp -vr ./build/* /var/www/html/$AppNameToRouteLocation</li>
        </ol>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
